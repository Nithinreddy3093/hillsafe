import React from 'react';
import { Shield, Mountain, Users } from 'lucide-react';

export function About() {
  return (
    <div className="bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white sm:text-5xl">
            About HillSafe
          </h1>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Your trusted companion for safe mountain adventures
          </p>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
            <div className="flex flex-col items-center">
              <Shield className="w-12 h-12 text-blue-600" />
              <h3 className="mt-4 text-xl font-semibold text-gray-900 dark:text-white">Our Mission</h3>
              <p className="mt-2 text-center text-gray-600 dark:text-gray-300">
                To make mountain adventures safer and more accessible for everyone through technology and community support.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <Mountain className="w-12 h-12 text-blue-600" />
              <h3 className="mt-4 text-xl font-semibold text-gray-900 dark:text-white">Our Vision</h3>
              <p className="mt-2 text-center text-gray-600 dark:text-gray-300">
                Creating a world where every mountain enthusiast can explore with confidence, knowing they have the tools and support they need.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <Users className="w-12 h-12 text-blue-600" />
              <h3 className="mt-4 text-xl font-semibold text-gray-900 dark:text-white">Our Community</h3>
              <p className="mt-2 text-center text-gray-600 dark:text-gray-300">
                A growing network of passionate hikers and mountaineers sharing knowledge and supporting each other.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-20">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white text-center">How We Help</h2>
          <div className="mt-8 prose prose-blue mx-auto dark:prose-invert">
            <p>
              HillSafe combines cutting-edge technology with community wisdom to provide:
            </p>
            <ul>
              <li>Real-time weather and safety alerts</li>
              <li>GPS tracking and route sharing</li>
              <li>Emergency assistance coordination</li>
              <li>Community-driven trail reports and tips</li>
              <li>Expert-verified safety guidelines</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}