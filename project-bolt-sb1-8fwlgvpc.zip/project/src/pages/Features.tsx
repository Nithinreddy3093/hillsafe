import React from 'react';
import { Shield, Map, Users, Bell, Compass, Cloud, Phone, Heart } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Safety First',
    description: 'Real-time alerts about weather changes, avalanche risks, and emergency situations.',
  },
  {
    icon: Map,
    title: 'Trail Navigation',
    description: 'Advanced GPS tracking with offline maps and route sharing capabilities.',
  },
  {
    icon: Users,
    title: 'Community Support',
    description: 'Connect with experienced hikers, share tips, and join group expeditions.',
  },
  {
    icon: Bell,
    title: 'Smart Notifications',
    description: 'Customizable alerts for weather changes, nearby hikers, and safety updates.',
  },
  {
    icon: Compass,
    title: 'Route Planning',
    description: 'Plan your adventures with detailed trail information and difficulty ratings.',
  },
  {
    icon: Cloud,
    title: 'Weather Insights',
    description: 'Detailed weather forecasts and conditions specific to hiking trails.',
  },
  {
    icon: Phone,
    title: 'Emergency SOS',
    description: 'One-tap emergency contact with precise location sharing.',
  },
  {
    icon: Heart,
    title: 'Health Monitoring',
    description: 'Track your activity, elevation gain, and hiking stats.',
  },
];

export function Features() {
  return (
    <div className="bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white sm:text-5xl">
            Features
          </h1>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Everything you need for safe and enjoyable mountain adventures
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <div key={feature.title} className="relative">
              <dt>
                <div className="absolute flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600 text-white">
                  <feature.icon className="h-6 w-6" aria-hidden="true" />
                </div>
                <p className="ml-16 text-lg font-semibold leading-6 text-gray-900 dark:text-white">
                  {feature.title}
                </p>
              </dt>
              <dd className="mt-2 ml-16 text-base text-gray-600 dark:text-gray-300">
                {feature.description}
              </dd>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}