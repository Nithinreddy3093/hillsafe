import React from 'react';
import { useAuthStore } from '@/features/auth/store';
import { MapPin, Calendar, Bell } from 'lucide-react';

export function Dashboard() {
  const user = useAuthStore((state) => state.user);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name}!</h1>
        <p className="text-gray-600">Here's your hiking activity overview</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <MapPin className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-lg font-semibold">Recent Trails</h2>
          </div>
          <div className="space-y-3">
            <p className="text-gray-600">Mount Rainier Loop</p>
            <p className="text-gray-600">Cascade Pass Trail</p>
            <p className="text-gray-600">Olympic Coast Trail</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <Calendar className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-lg font-semibold">Upcoming Hikes</h2>
          </div>
          <div className="space-y-3">
            <p className="text-gray-600">Mt. Baker Summit - Next Week</p>
            <p className="text-gray-600">Columbia River Gorge - In 2 weeks</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center mb-4">
            <Bell className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-lg font-semibold">Safety Alerts</h2>
          </div>
          <div className="space-y-3">
            <p className="text-yellow-600">Weather Alert: Storm expected this weekend</p>
            <p className="text-green-600">Trail Conditions: Clear at Paradise Point</p>
          </div>
        </div>
      </div>
    </div>
  );
}