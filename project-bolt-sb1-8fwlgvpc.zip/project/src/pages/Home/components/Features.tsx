import React from 'react';
import { Shield, Map, Users } from 'lucide-react';
import { FeatureCard } from './FeatureCard';

const features = [
  {
    icon: Shield,
    title: 'Real-time Safety Alerts',
    description: 'Get instant notifications about weather changes, avalanche risks, and emergency situations.',
  },
  {
    icon: Map,
    title: 'Trail Tracking',
    description: 'Track your routes, share your location with friends, and discover new trails.',
  },
  {
    icon: Users,
    title: 'Community Support',
    description: 'Connect with experienced hikers, share tips, and join group expeditions.',
  },
];

export function Features() {
  return (
    <div className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-blue-600">Safety First</h2>
          <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Everything you need for safe mountain adventures
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            {features.map((feature) => (
              <FeatureCard key={feature.title} {...feature} />
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}