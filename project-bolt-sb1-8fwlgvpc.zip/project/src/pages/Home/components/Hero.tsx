import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/Button';

export function Hero() {
  return (
    <div className="relative isolate">
      <div className="absolute inset-0 bg-hero-pattern bg-cover bg-center bg-no-repeat">
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
      </div>
      
      <div className="relative mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
            Your Safety Companion in the Mountains
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-100">
            Track your adventures, stay safe, and connect with fellow hikers. HillSafe provides real-time safety features and community support for all your mountain expeditions.
          </p>
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <Link to="/register">
              <Button size="lg">Get Started</Button>
            </Link>
            <Link to="/features">
              <Button variant="outline" size="lg" className="text-white border-white hover:bg-white/10">
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}