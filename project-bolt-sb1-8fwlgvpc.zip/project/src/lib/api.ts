// API response types
export interface ApiResponse<T> {
  data?: T;
  error?: string;
}

export class ApiError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

// Simulated API delay
export const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));