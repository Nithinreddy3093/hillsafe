import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useNavigate } from 'react-router-dom';
import { registerSchema } from '../validation';
import { useAuthStore } from '../store';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { useRegisterMutation } from '../api';
import type { RegisterFormData } from '../types';

export function RegisterForm() {
  const navigate = useNavigate();
  const login = useAuthStore((state) => state.login);
  const { mutateAsync: register, isLoading } = useRegisterMutation();

  const {
    register: registerField,
    handleSubmit,
    formState: { errors },
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
  });

  const onSubmit = async (data: RegisterFormData) => {
    try {
      const user = await register(data);
      login(user);
      navigate('/dashboard');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Input
          placeholder="Name"
          {...registerField('name')}
          error={errors.name?.message}
        />
      </div>
      <div>
        <Input
          type="email"
          placeholder="Email"
          {...registerField('email')}
          error={errors.email?.message}
        />
      </div>
      <div>
        <Input
          type="password"
          placeholder="Password"
          {...registerField('password')}
          error={errors.password?.message}
        />
      </div>
      <div>
        <Input
          type="password"
          placeholder="Confirm Password"
          {...registerField('confirmPassword')}
          error={errors.confirmPassword?.message}
        />
      </div>
      <Button type="submit" className="w-full" isLoading={isLoading}>
        Create Account
      </Button>
    </form>
  );
}