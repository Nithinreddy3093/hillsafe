import { User, LoginFormData, RegisterFormData } from './types';
import { ApiResponse, ApiError, delay } from '@/lib/api';

export const useLoginMutation = () => {
  const loginMutation = async (credentials: LoginFormData): Promise<User> => {
    await delay(1000);
    
    // Simulate API validation
    if (credentials.email === 'error@test.com') {
      throw new ApiError('Invalid credentials');
    }

    return {
      id: '1',
      email: credentials.email,
      name: 'John Doe',
    };
  };

  return {
    mutateAsync: loginMutation,
    isLoading: false,
  };
};

export const useRegisterMutation = () => {
  const registerMutation = async (data: RegisterFormData): Promise<User> => {
    await delay(1000);
    
    // Simulate API validation
    if (data.email === 'taken@test.com') {
      throw new ApiError('Email already taken');
    }

    return {
      id: '2',
      email: data.email,
      name: data.name,
    };
  };

  return {
    mutateAsync: registerMutation,
    isLoading: false,
  };
};