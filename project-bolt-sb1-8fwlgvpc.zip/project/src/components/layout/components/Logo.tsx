import React from 'react';
import { Link } from 'react-router-dom';
import { Mountain } from 'lucide-react';

export function Logo() {
  return (
    <Link to="/" className="flex items-center">
      <Mountain className="h-8 w-8 text-blue-600" />
      <span className="ml-2 text-xl font-bold text-gray-900">HillSafe</span>
    </Link>
  );
}