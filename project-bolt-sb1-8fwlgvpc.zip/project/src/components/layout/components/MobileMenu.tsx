import React from 'react';
import { NavLinks } from './NavLinks';

interface MobileMenuProps {
  isOpen: boolean;
}

export function MobileMenu({ isOpen }: MobileMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="sm:hidden">
      <div className="pt-2 pb-3 space-y-1">
        <NavLinks isMobile />
      </div>
    </div>
  );
}