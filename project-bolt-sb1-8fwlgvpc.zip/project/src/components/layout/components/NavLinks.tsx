import React from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '@/features/auth/store';
import { Button } from '@/components/ui/Button';

interface NavLinksProps {
  isMobile?: boolean;
}

export function NavLinks({ isMobile = false }: NavLinksProps) {
  const { isAuthenticated, logout } = useAuthStore();
  const baseClassName = isMobile
    ? "block px-3 py-2 text-base font-medium text-gray-500 hover:text-gray-900 hover:bg-gray-50"
    : "text-gray-500 hover:text-gray-900";

  return (
    <>
      <Link to="/features" className={baseClassName}>Features</Link>
      <Link to="/about" className={baseClassName}>About</Link>
      {isAuthenticated ? (
        <>
          <Link to="/dashboard" className={baseClassName}>Dashboard</Link>
          <Button variant="outline" onClick={() => logout()}>Sign Out</Button>
        </>
      ) : (
        <>
          <Link to="/login">
            <Button variant="outline">Sign In</Button>
          </Link>
          <Link to="/register">
            <Button>Sign Up</Button>
          </Link>
        </>
      )}
    </>
  );
}